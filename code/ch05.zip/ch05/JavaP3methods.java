class JavaP3methods
{
	void f(){}
	private void p(){}
	static void s(){}

	public static void main(String...argv){
		JavaP3methods obj = new JavaP3methods();
		obj.f();
		obj.p();
		obj.s();
	}
}