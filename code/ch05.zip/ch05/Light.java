enum Light { Red, Yellow, Green };
