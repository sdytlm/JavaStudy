 public class FloatEqualsTest{
 public static void main( String args[] ){
 float A = 1.0F / 3.0F ;
 if( ( A * 3.0) == 1.0F )
     System.out.println( "Equal" );
 else System.out.println( "Not Equal" );
 }
 }
